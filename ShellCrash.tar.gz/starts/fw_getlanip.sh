getlanip() { #获取局域网host地址
    i=1
    while [ "$i" -le "20" ]; do
        #ipv4局域网网段
        host_ipv4=$(ip route show scope link | grep -Ev 'default|wan|utun|iot|peer|docker|podman|virbr|vnet|ovs|vmbr|veth|vmnic|vboxnet|lxcbr|xenbr|vEthernet|wgs|multicast|anycast' | awk '{print $1}')
        #ipv6局域网网段 - 从IPv4已识别的LAN接口获取全局IPv6前缀
        [ "$ipv6_redir" = "ON" ] && {
            lan_ifaces=$(ip route show scope link | grep -Ev 'ppp|wan|utun|iot|peer|docker|podman|virbr|vnet|ovs|vmbr|veth|vmnic|vboxnet|lxcbr|xenbr|vEthernet|wgs|multicast|anycast' | awk '{for(i=1;i<=NF;i++) if($i=="dev") {print $(i+1); break}}' | grep -v '^lo$' | sort -u)
            host_ipv6=$(
                for iface in $lan_ifaces; do
                    ip -6 addr show dev $iface 2>/dev/null
                done | grep 'scope global' | awk '{print $2}' | tr '\n' ' ' | sed 's/ $//'
            )
			[ -z "$host_ipv6" ] && host_ipv6=$(ip -6 route show | grep -Ev 'default|unreachable|fe80::/|wan|ppp|utun|iot|peer|docker|podman|virbr|vnet|ovs|vmbr|veth|vmnic|vboxnet|lxcbr|xenbr|vEthernet|wgs|multicast|anycast' | awk '{print $1}' | tr '\n' ' ' | sed 's/ $//')
        }
        [ -f "$TMPDIR"/ShellCrash.log ] && break
        [ -n "$host_ipv4" -a "$ipv6_redir" != "ON" ] && break
        [ -n "$host_ipv4" -a -n "$host_ipv6" ] && break
        sleep 1 && i=$((i + 1))
    done
    #Tailscale
    [ "$ts_service" = ON ] && {
        ts_host_ipv4=' 100.64.0.0/10'
        ts_host_ipv6=' fd7a:115c:a1e0::/48'
    }
    #Wireguard
    [ "$wg_service" = ON ] && {
        . "$CRASHDIR"/configs/gateway.cfg
        wg_host_ipv4=' $wg_ipv4'
        [ -n "$wg_ipv6" ] && wg_host_ipv6=' $wg_ipv6'
    }
    #添加自定义ipv4局域网网段
    if [ "$replace_default_host_ipv4" = "ON" ]; then
        host_ipv4="$cust_host_ipv4"
    else
        host_ipv4=$(echo "$host_ipv4 $cust_host_ipv4$ts_host_ipv4$wg_host_ipv4" | tr '\n' ' ' | sed 's/ $//')
    fi
    #缺省配置
    [ -z "$host_ipv4" ] && {
        host_ipv4='192.168.0.0/16 10.0.0.0/12 172.16.0.0/12'
        logger "无法获取本地LAN-IPV4网段，请前往流量过滤设置界面设置自定义网段！" 31
    }
    host_ipv6="fe80::/10 fd00::/8 $host_ipv6$ts_host_ipv6$wg_host_ipv6"
    #获取本机出口IP地址
    local_ipv4=$(ip route 2>&1 | grep -Ev 'utun|iot|docker|linkdown' | grep -Eo 'src.*' | grep -Eo '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | sort -u)
    [ -z "$local_ipv4" ] && local_ipv4=$(ip route 2>&1 | grep -Eo 'src.*' | grep -Eo '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | sort -u)
    #补全PPPoE/多出口场景的本机WAN源地址，避免本机OUTPUT规则漏匹配
    local_wan_ipv4=$(for target in 1.1.1.1 8.8.8.8 114.114.114.114; do ip route get "$target" 2>/dev/null | grep -Eo 'src [0-9]{1,3}(\.[0-9]{1,3}){3}' | awk '{print $2}'; done | sort -u)
    [ -n "$local_wan_ipv4" ] && local_ipv4=$(echo "$local_ipv4 $local_wan_ipv4" | tr ' ' '\n' | grep -v '^$' | sort -u)
    #补全PPPoE/多出口场景的本机WAN IPv6源地址，避免本机OUTPUT规则漏匹配
    #注意：WAN IPv6只放入local_ipv6供OUTPUT使用，不要合并进host_ipv6污染LAN/INPUT规则
    [ "$ipv6_redir" = "ON" ] && local_wan_ipv6=$(for target in 2001:4860:4860::8888 2606:4700:4700::1111 2400:3200::1; do ip -6 route get "$target" 2>/dev/null | grep -Eo 'src [0-9A-Fa-f:.]+' | awk '{print $2"/128"}'; done | sort -u)
    local_ipv6="$host_ipv6"
    [ -n "$local_wan_ipv6" ] && local_ipv6=$(echo "$local_ipv6 $local_wan_ipv6" | tr ' ' '\n' | grep -v '^$' | sort -u)
    #保留地址
    [ -z "$reserve_ipv4" ] && reserve_ipv4="0.0.0.0/8 10.0.0.0/8 127.0.0.0/8 100.64.0.0/10 169.254.0.0/16 172.16.0.0/12 192.168.0.0/16 224.0.0.0/4 240.0.0.0/4"
    [ -z "$reserve_ipv6" ] && reserve_ipv6="::/128 ::1/128 ::ffff:0:0/96 64:ff9b::/96 100::/64 2001::/32 2001:20::/28 2001:db8::/32 2002::/16 fe80::/10 ff00::/8"
}
